from setuptools import setup

setup(
    author="Rodrigo Lezama",
    author_email="rodrigo.lezama.179@gmail.com",
    description="Practica n°2 Python",
    version="0.0.1",
    name="Ejercicio2Python",
    packages= ["Practica1", "Practica2"]
)